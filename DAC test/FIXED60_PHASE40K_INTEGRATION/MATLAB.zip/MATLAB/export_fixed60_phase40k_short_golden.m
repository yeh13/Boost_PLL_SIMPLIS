function export_fixed60_phase40k_short_golden()
% Verification-only helper. It does not change the candidate algorithm.
% Generates a short deterministic 60 Hz golden trace for full RTL parity checking.
root_dir=fileparts(mfilename('fullpath')); addpath(root_dir);

c=firmware_config();
Fs=40000; Fpll=5000; duration=2.0; % short, deterministic, easy to debug

tadc=(0:Fs*duration-1)'/Fs;
adc=uint16(round(2048 + 1860*sin(2*pi*60*tadc)));
[r,pdiag]=stage17_model_60hz(adc,'locked_fixed_60');

% Current stage17_model_60hz pdiag contract:
% col1 = hold
% col2 = entry_count
% col3 = release_count
% col4 = theta_before
% col5 = integration_residual
% col6 = target_minus_previous_step
% col7 = after_frequency_deadband
assert(size(pdiag,2)==7,'Unexpected stage17_model_60hz diagnostic format: expected 7 columns.');
assert(size(r,2)==18,'Unexpected stage17_model_60hz output format: expected 18 columns.');

% Use the same authoritative sources already used by run_fixed60_phase40k.m.
anchors=pdiag(:,4); % pre-update PLL phase anchor at each 5 kHz update
steps=r(:,12);      % actual_step from the 5 kHz model output
valid=r(:,2)~=0;

d=phase_delivery_8tick(anchors,steps,valid,c.full);
idx=repelem((1:numel(anchors))',8);
idx=idx(1:end-7);
M=d.modulus;

time_s=tadc(8:end);
held=anchors(idx)*8;
theta=double(d.trace(:,2));
base=double(d.trace(:,3));
phase_error=double(d.trace(:,4));
q=double(d.trace(:,5));
remainder=double(d.trace(:,6));
applied=double(d.trace(:,7));
remaining=double(d.trace(:,8));
substep=double(d.trace(:,9));
inc=double(d.trace(:,10));
held_phase=double(held);
extrapolated_phase=double(theta);
held_ref=sine_q15_ticks(held,M,c.sin);
extrapolated_ref=sine_q15_ticks(theta,M,c.sin);

hold_flags = double(pdiag(:,1)); % current diagnostic rollout: hold flag is pdiag(:,1)
phase_ok_flags = double(r(:,14)); % current model output: phase_ok is column 14
locked_flags = double(r(:,15));   % current model output: locked is column 15
actual_step = double(r(:,12));    % current model output: actual_step is column 12
pll_step_q = double(r(:,12));     % same source as actual_step

out = table(time_s(:), held_phase(:), pll_step_q(:), actual_step(:), hold_flags(:), phase_ok_flags(:), locked_flags(:), ...
    extrapolated_phase(:), base(:), phase_error(:), q(:), remainder(:), applied(:), remaining(:), substep(:), ...
    held_ref(:), extrapolated_ref(:), 'VariableNames', {...
    'time_s','pll_phase_anchor','pll_step_q','actual_step','hold_60hz','phase_ok','locked', ...
    'theta_40k','base_step_40k','phase_error','correction_quotient','correction_remainder', ...
    'correction_applied','correction_remaining','substep','held_phase','extrapolated_phase','held_ref','extrapolated_ref'});

outdir=fullfile(root_dir,'RESULTS');
if ~exist(outdir,'dir'), mkdir(outdir); end
outpath=fullfile(outdir,'golden_fixed60_phase40k_short.csv');
writetable(out,outpath);
fprintf('Wrote short golden trace: %s\n', outpath);
end
