/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef PARAMETER_H
#define PARAMETER_H

#include <xc.h>
#include <stdint.h> 

#ifdef __cplusplus
extern "C" {
#endif

/* =========================
 * PLL / Synchronization
 * ========================= */

typedef enum {
    PLL_FREE_RUN = 0,
    PLL_LOCKED
} pll_mode_t;

extern pll_mode_t pll_mode;
extern float pll_theta;    // ? ?? volatile

extern float pll_integ;    // ? ????????????? pll_integ?

/* ?????? / ? PLL ?? */
extern volatile uint8_t pll_locked;     // ? extern only

/* ? AN0 ??????? i_ref?counts? */
extern volatile int16_t i_ref_count;    // ? extern only

/* =========================
 * Modulation / Phase State
 * ========================= */
extern unsigned short phase;
extern unsigned short i;
extern unsigned short k;

/* =========================
 * DC / Reference Tables
 * ========================= */
extern const int16_t Vdc;
extern const int16_t VrefTable[334];

/* =========================
 * PWM / Control Outputs
 * ========================= */
extern int32_t Buck_PWM;
extern int32_t Boost_PWM;

extern int16_t finallyDuty_buck;
extern int16_t finallyDuty_boost;

/* =========================
 * Boost Dynamic Compensation
 * ========================= */
extern int32_t boost_dynamic_coefficient;
extern int32_t B_Coefficient_BOOST_finally[3];

/* ====== Calibration (macro OK ? header ???) ====== */
#define COUNTS_PER_AMP      460
#define I_RMS_TARGET_A      0.5f
#define I_PEAK_TARGET_COUNTS ((int16_t)(I_RMS_TARGET_A * 1.41421356f * COUNTS_PER_AMP))
#define IREF_PHASE_COMP     0.0f
#ifdef __cplusplus
}
#endif

#endif /* PARAMETER_H */




